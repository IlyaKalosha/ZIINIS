
-Create private keys over a public channel using neural networks. 

For basic use:
  python Main.py -numHidden 20 -inputLength 500 -concurrent


More to come..
